package com;

public class User {
	private int id;
	private String flight_number;
	private String flight_name;
	private String flight_price;
	private int booking_seats;
	private String username;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFlight_number() {
		return flight_number;
	}
	public void setFlight_number(String flight_number) {
		this.flight_number = flight_number;
	}
	public String getFlight_name() {
		return flight_name;
	}
	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}
	public String getFlight_price() {
		return flight_price;
	}
	public void setFlight_price(String flight_price) {
		this.flight_price = flight_price;
	}
	public int getBooking_seats() {
		return booking_seats;
	}
	public void setBooking_seats(int booking_seats) {
		this.booking_seats = booking_seats;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	

}
