package arraysprogram;

public class Arryas {



		public static void main(String[] args) {

		int y[]= {10,20,30,40,50};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array y: "+y[i]);
		}

		int[][] m = {
		            {9, 12, 9, 4}, 
		            {8, 6, 9} };
		      
		      System.out.println("\nLength of row 1: " + m[0].length);
		      }
		}
