package thread;

public class Myrunnable extends Thread {
	
	 	public void run()
	 	{
	  		System.out.println("concurrent thread started running..");
	}
	 	public static void main( String args[] )
	 	{
	  		Myrunnable mt = new  Myrunnable();
	  		mt.start();
	 	}
	}
