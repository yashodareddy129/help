package method.p1;

public class M {
	private int age=18;
	long y=4129;
	protected float percentage=83.3f;
	
	public void publicmethod() 
	{
		System.out.println("Class M is in public method");
	}
	void defaultmethod()
	{
		System.out.println("Class M is in default method");
		
	}
	private void privatemethod()
	{
		System.out.println("Class M is in private method");
	}
	protected void protectedmethod()
	{
		System.out.println("Class M is in protected method");
	}


}
