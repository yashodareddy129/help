package method.p1;

public class N {
	protected long aadhar=990854;
	public int marks =90;
	double meters=15.5;
	
	public void publicmethod() 
	{
		System.out.println("Class N is in public method");
	}
	void defaultmethod()
	{
		System.out.println("Class N is in default method");
		
	}
	private void privatemethod()
	{
		System.out.println("Class N is in private method");
	}
	protected void protectedmethod()
	{
		System.out.println("Class N is in protected method");
	}

}
