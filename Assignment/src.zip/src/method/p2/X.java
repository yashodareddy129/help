package method.p2;

public class X {
	private int h=78;
	long e=678;
	protected float f=74.77f;
	public char name='y';
	

}
