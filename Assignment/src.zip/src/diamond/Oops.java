package diamond;
	interface First 
	{  
	    default void show() 
	    { 
	        System.out.println(" First Class"); 
	    } 
	} 
	interface Second 
	{  
	    default void show() 
	    { 
	        System.out.println(" Second Class"); 
	    } 
	}  
	public class Oops implements First,Second {
		
		  
		    public void show() 
		    {  
		        First.super.show(); 
		        Second.super.show(); 
		    } 
		    public static void main(String args[]) 
		    { 
		        Oops ob = new Oops(); 
		        ((First) ob).show(); 
		    }
	}