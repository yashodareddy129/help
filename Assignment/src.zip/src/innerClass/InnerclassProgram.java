package innerClass;
public class InnerclassProgram {

	 private String output="here  is  Java Training"; 
	 
	 class Inner{  
	  void hello(){System.out.println(output+", Now we will start  learning Inner Classes");}  
	 }  


	public static void main(String[] args) {

		InnerclassProgram obj=new InnerclassProgram();
		InnerclassProgram.Inner in=obj.new Inner();  
		in.hello();  
	}
}


